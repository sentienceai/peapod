/**
 * Shared preview chrome: the theme switch.
 *
 * Saved under localStorage `peapod-theme`, as the handoff specifies. Storage can be absent
 * or throw (private windows, blocked site data), and the page must render either way, so
 * every read and write is guarded and the default is the handoff's light theme.
 */

const KEY = 'peapod-theme';

/** @returns {'light' | 'dark'} */
function saved() {
  try {
    return globalThis.localStorage?.getItem(KEY) === 'dark' ? 'dark' : 'light';
  } catch {
    return 'light';
  }
}

/** @param {'light' | 'dark'} theme */
function apply(theme) {
  const root = /** @type {any} */ (document).documentElement;
  if (root?.setAttribute) root.setAttribute('data-theme', theme);
  const toggle = document.getElementById('theme-toggle');
  if (toggle) {
    const label = theme === 'dark' ? 'Switch to day mode' : 'Switch to night mode';
    toggle.setAttribute('aria-label', label);
    toggle.setAttribute('title', label);
  }
}

export function mountTheme() {
  let theme = saved();
  apply(theme);
  const toggle = document.getElementById('theme-toggle');
  if (!toggle) return;
  toggle.onclick = () => {
    theme = theme === 'dark' ? 'light' : 'dark';
    apply(theme);
    try { globalThis.localStorage?.setItem(KEY, theme); } catch { /* storage refused */ }
  };
}

/**
 * @template {keyof HTMLElementTagNameMap} K
 * @param {K} tag @param {string} [cls] @param {string} [text]
 * @returns {HTMLElementTagNameMap[K]}
 */
export function node(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined) n.textContent = text;
  return n;
}

const usd2 = new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const usd0 = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 });
/** @param {number} n */
export const money = (n) => `$${Math.abs(n) < 10000 ? usd2.format(Math.abs(n)) : usd0.format(Math.round(Math.abs(n)))}`;

/**
 * Signed money, carrying the sign three ways: glyph, sign character, colour.
 * @param {number} n
 */
export function signedMoney(n) {
  const s = node('strong', n >= 0 ? 'up' : 'down');
  s.append(node('span', 'mark', n >= 0 ? '▲' : '▼'));
  s.append(document.createTextNode(`${n >= 0 ? '+' : '−'}${money(n)}`));
  return s;
}

/** @param {string} a */
export const shortAddr = (a) => `${a.slice(0, 6)}…${a.slice(-4)}`;

const SVG = 'http://www.w3.org/2000/svg';
/**
 * A stroked icon from path data, built as nodes rather than parsed from a string.
 * @param {number} size @param {[string, Record<string, string | number>][]} parts
 * @param {Record<string, string | number>} [attrs]
 */
export function icon(size, parts, attrs = {}) {
  const svg = document.createElementNS(SVG, 'svg');
  for (const [k, v] of Object.entries({ width: size, height: size, viewBox: '0 0 24 24', fill: 'none',
    'stroke-width': 2, 'stroke-linecap': 'round', 'aria-hidden': 'true', ...attrs })) {
    svg.setAttribute(k, String(v));
  }
  for (const [tag, a] of parts) {
    const p = document.createElementNS(SVG, tag);
    for (const [k, v] of Object.entries(a)) p.setAttribute(k, String(v));
    svg.append(p);
  }
  return svg;
}
export const CLOSE = /** @type {[string, Record<string, string>][]} */ ([['path', { d: 'M6 6l12 12M18 6L6 18' }]]);
