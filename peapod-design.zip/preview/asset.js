/**
 * Asset page (preview): the shell, with every metric unwired.
 *
 * Holders, average entry and the share of holders in profit need the transfer index: a
 * holder may never have swapped, so only transfers say who holds. Price, volume and recent
 * trades are already in the swap tape but nothing serves them per asset yet. Until either
 * lands, each slot says which of the two it is waiting for.
 *
 * The page does not claim the symbol exists. There is no asset endpoint to ask, so it says
 * that rather than rendering a confident header over a ticker someone typed.
 */

import { unwired } from './needs.js';
import { mountTheme, node } from './chrome.js';

/** @param {string} id */
const el = (id) => /** @type {HTMLElement} */ (document.getElementById(id));

/**
 * The symbol from /asset/:symbol, shape-checked the same way the server gate checks it.
 * @param {string} pathname
 */
export function symbolFrom(pathname) {
  const raw = decodeURIComponent(String(pathname).replace(/^\/asset\//, ''));
  return /^[A-Za-z0-9.]{1,16}$/.test(raw) ? raw.toUpperCase() : null;
}

/** @param {string} pathname */
export function renderAsset(pathname) {
  const symbol = symbolFrom(pathname);
  const shown = symbol ?? 'Unknown';
  el('crumb').textContent = shown;
  el('symbol').textContent = shown;
  el('icon').textContent = shown.slice(0, 1);
  if (typeof document.title === 'string') document.title = `${shown} · peapod preview`;
  el('asset-sub').textContent = 'Robinhood Chain · not yet confirmed: no asset endpoint to check against';

  el('price').replaceChildren(unwired('price'));

  const stats = el('stats');
  stats.replaceChildren(unwired('holders'), unwired('volume24h'), unwired('inProfit'), unwired('avgEntry'));

  const chart = el('chart');
  const priceBlock = unwired('price');
  priceBlock.className = `${priceBlock.className} unwired--block`;
  chart.replaceChildren(node('span', 'setup-label', 'Price'), priceBlock);

  el('cluster-sub').textContent = `Each bubble will be a wallet holding ${shown}, sized by position.`;
  el('cluster').replaceChildren(unwired('holders'));

  el('holders').replaceChildren(unwired('holders'));

  el('trades-title').textContent = `Recent ${shown} trades`;
  el('trades').replaceChildren(unwired('recentTrades'));

  const f = el('footnote');
  const back = node('a', 'linkish', 'Back to copy trade');
  back.setAttribute('href', '/copy-trade');
  f.replaceChildren(node('span', undefined, 'Preview'), node('span', 'pfoot-sep'),
    node('span', undefined, 'Nothing on this page is measured yet. Each slot names what it is waiting for.'),
    node('span', 'pfoot-sep'), back);
}

mountTheme();
renderAsset(globalThis.location?.pathname ?? '');
