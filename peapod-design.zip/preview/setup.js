/**
 * Copy setup (preview): the handoff's two-step dialog, with nothing behind its last button.
 *
 * REAL: the trader's realized figure, closes and chance verdict from the build; the
 * tokens they traded in the window; every control, held in local state.
 *
 * UNWIRED: account value, the simulated return, the funding balance, and connecting an
 * existing wallet — each rendered as what it needs. Start is disabled, and says why beside
 * it. There is no step three: the mockup's "Copy trade is live" screen would be the one
 * false sentence this page could reach, so it does not exist until execution does.
 *
 * NO WALLET CALLS. This module does not touch an injected wallet or any provider. The live
 * site's wallet is connect-only and asserted so; this page has nothing to connect to yet,
 * and a test fails if a provider method name appears in any preview source.
 */

import { chanceBand } from '../web/lib/evidence.js';
import { unwired } from './needs.js';
import { CLOSE, icon, node, shortAddr, signedMoney } from './chrome.js';

/** @param {string} id */
const el = (id) => /** @type {HTMLElement} */ (document.getElementById(id));

/** @typedef {{ id: string, label: string, desc: string, kind: 'range' | 'switch',
 *   min?: number, max?: number, step?: number, unit?: string, sign?: string }} Setting */

/** @type {Record<string, Setting[]>} */
const TABS = {
  Configuration: [
    { id: 'maxSize', label: 'Max size per trade', desc: 'Caps each copied buy as a share of your copy wallet.', kind: 'range', min: 1, max: 50, step: 1, unit: '%' },
    { id: 'memes', label: 'Include memecoin trades', desc: 'Also mirror this trader’s Pons memecoin buys and sells.', kind: 'switch' },
    { id: 'newOnly', label: 'Only copy new positions', desc: 'Skip holdings the trader already had before you started.', kind: 'switch' },
    { id: 'worse', label: 'Max worse entry', desc: 'Skip a trade if your price is this much worse than theirs.', kind: 'range', min: 0.5, max: 10, step: 0.5, unit: '%' },
  ],
  Settings: [
    { id: 'stop', label: 'Stop loss', desc: 'Pause copying if your copy wallet falls this far.', kind: 'range', min: 5, max: 50, step: 1, unit: '%', sign: '−' },
    { id: 'take', label: 'Take profit', desc: 'Pause copying once your copy wallet is up this much.', kind: 'range', min: 10, max: 200, step: 5, unit: '%', sign: '+' },
    { id: 'idle', label: 'Pause if inactive', desc: 'Stop if the trader makes no trades for this long.', kind: 'range', min: 1, max: 30, step: 1, unit: 'days' },
    { id: 'alerts', label: 'Trade alerts', desc: 'Notify me every time a trade is copied.', kind: 'switch' },
  ],
};

/** The dialog's settings. Defaults are the mockup's; they are preferences, not figures. */
const DEFAULTS = { maxSize: 10, memes: false, newOnly: true, worse: 1, stop: 15, take: 30, idle: 7, alerts: true };

const s = {
  /** @type {any} */ row: null,
  windowLabel: '',
  /** @type {HTMLElement | null} */ from: null,
  step: 1,
  mode: /** @type {'copy' | 'counter'} */ ('copy'),
  tab: 'Configuration',
  funding: /** @type {'new' | 'existing'} */ ('new'),
  token: /** @type {'USDG' | 'ETH'} */ ('USDG'),
  amount: '',
  /** @type {string[]} */ extra: [],
  addError: '',
  /** @type {Record<string, number | boolean>} */ values: { ...DEFAULTS },
  /** @type {Record<string, boolean>} */ assets: {},
};

/** @param {string} label @param {boolean} on @param {() => void} flip */
function toggle(label, on, flip) {
  const b = node('button', 'switch');
  b.type = 'button';
  b.setAttribute('aria-pressed', String(on));
  b.setAttribute('aria-label', label);
  b.append(node('i'));
  b.onclick = () => { flip(); render(); };
  return b;
}

/** @param {Setting} set */
function range(set) {
  const v = Number(s.values[set.id]);
  const pct = ((v - (set.min ?? 0)) / ((set.max ?? 1) - (set.min ?? 0))) * 100;
  const box = node('div', 'range');
  const track = node('div', 'range-track');
  const fill = node('i', 'range-fill');
  fill.style.width = `${pct}%`;
  const handle = node('i', 'range-handle');
  handle.style.left = pct > 96 ? 'calc(100% - 6px)' : `calc(${pct}% - 2px)`;
  const input = /** @type {HTMLInputElement} */ (node('input'));
  input.type = 'range';
  input.min = String(set.min);
  input.max = String(set.max);
  input.step = String(set.step);
  input.value = String(v);
  input.setAttribute('aria-label', set.label);
  input.oninput = () => { s.values[set.id] = Number(input.value); render(); };
  track.append(fill, handle, input);
  const out = node('div', 'range-out');
  out.append(node('b', undefined, `${set.sign ?? ''}${set.step && set.step < 1 ? v.toFixed(1) : v}`),
    node('span', undefined, set.unit ?? ''));
  box.append(track, out);
  return box;
}

/** @param {string} label @param {string} desc @param {HTMLElement} control */
function settingRow(label, desc, control) {
  const r = node('div', 'srow');
  const text = node('div', 'srow-text');
  text.append(node('b', undefined, label), node('span', undefined, desc));
  r.append(text, control);
  return r;
}

function stepOne() {
  const r = s.row;
  const b = chanceBand(r.wins, r.round_trips);
  const frag = node('div');

  const stats = node('div', 'setup-stats');
  stats.append(unwired('accountValue'));
  const realized = node('div', 'stat');
  realized.append(node('span', 'stat-label', `Realized · ${s.windowLabel}`));
  const rv = signedMoney(r.realized);
  rv.className = `${rv.className} stat-value`;
  realized.append(rv, node('span', 'stat-sub', 'Round-trips only'));
  const win = node('div', 'stat');
  // A rate, not a signed quantity: neutral, with the chance verdict in words beside it.
  win.append(node('span', 'stat-label', 'Win rate'), node('span', 'stat-value', `${(b.rate * 100).toFixed(1)}%`),
    node('span', 'stat-sub', `${b.label} · ${r.round_trips} closes`));
  stats.append(realized, win);
  frag.append(stats);

  const body = node('div', 'setup-body');
  const seg = node('div', 'setup-seg');
  seg.setAttribute('role', 'group');
  seg.setAttribute('aria-label', 'Mode');
  for (const [id, label] of /** @type {const} */ ([['copy', 'Copytrade'], ['counter', 'Countertrade']])) {
    const btn = node('button', undefined, label);
    btn.type = 'button';
    btn.setAttribute('aria-pressed', String(s.mode === id));
    btn.onclick = () => { s.mode = id; render(); };
    seg.append(btn);
  }
  body.append(seg);

  const wallets = node('div', 'setup-block');
  wallets.append(node('span', 'setup-label', 'Wallets'));
  const list = node('div', 'wallets');
  /** @param {string} addr @param {string} name @param {boolean} removable */
  const chip = (addr, name, removable) => {
    const c = node('div', 'wallet-chip');
    c.append(node('span', 'avatar', addr.slice(2, 4).toUpperCase()), node('b', undefined, name),
      node('span', 'mono', shortAddr(addr)));
    if (removable) {
      const x = node('button');
      x.type = 'button';
      x.setAttribute('aria-label', `Remove ${addr}`);
      x.append(icon(12, CLOSE, { 'stroke-width': 2.5 }));
      x.onclick = () => { s.extra = s.extra.filter((a) => a !== addr); render(); };
      c.append(x);
    }
    return c;
  };
  list.append(chip(r.address, 'This trader', false));
  s.extra.forEach((a, i) => list.append(chip(a, `Trader ${i + 2}`, true)));
  const add = node('div', 'add-row');
  const field = node('label', 'field');
  field.append(node('span', 'sr-only', 'Add another trader address'));
  const input = /** @type {HTMLInputElement} */ (node('input'));
  input.id = 'setup-add';
  input.placeholder = 'Add another trader address (0x…)';
  input.spellcheck = false;
  field.append(input);
  const addBtn = node('button', 'btn-secondary', 'Add');
  addBtn.type = 'button';
  addBtn.onclick = () => {
    const a = input.value.trim().toLowerCase();
    // A full address, not the mockup's six hex characters: a prefix names nobody.
    if (!/^0x[0-9a-f]{40}$/.test(a)) s.addError = 'That is not a full address.';
    else if (a === r.address || s.extra.includes(a)) s.addError = 'That wallet is already added.';
    else { s.extra.push(a); s.addError = ''; }
    render();
  };
  add.append(field, addBtn);
  wallets.append(list, add);
  if (s.addError) {
    const err = node('p', 'setup-error', s.addError);
    err.setAttribute('role', 'alert');
    wallets.append(err);
  }
  body.append(wallets);

  const sim = node('div', 'sim');
  const simSlot = unwired('simulatedReturn');
  simSlot.className = `${simSlot.className} unwired--block`;
  sim.append(simSlot);
  body.append(sim);
  frag.append(body);

  const tabs = node('div', 'setup-tabs');
  tabs.setAttribute('role', 'tablist');
  for (const name of ['Configuration', 'Assets', 'Settings']) {
    const t = node('button', undefined, name);
    t.type = 'button';
    t.setAttribute('role', 'tab');
    t.setAttribute('aria-selected', String(s.tab === name));
    t.onclick = () => { s.tab = name; render(); };
    tabs.append(t);
  }
  frag.append(tabs);

  const rows = node('div', 'rows');
  rows.setAttribute('role', 'tabpanel');
  if (s.tab === 'Assets') {
    // The tokens this address traded in the window. The mockup says "held by this trader";
    // holdings need the transfer index, so it says what is known instead.
    for (const t of r.tokens ?? []) {
      const on = s.assets[t] ?? true;
      rows.append(settingRow(t, `Traded by this address over ${s.windowLabel}`,
        toggle(`Copy ${t}`, on, () => { s.assets[t] = !on; })));
    }
  } else {
    for (const set of TABS[s.tab]) {
      const control = set.kind === 'switch'
        ? toggle(set.label, Boolean(s.values[set.id]), () => { s.values[set.id] = !s.values[set.id]; })
        : range(set);
      rows.append(settingRow(set.label, set.desc, control));
    }
  }
  frag.append(rows);
  return frag;
}

function stepTwo() {
  const body = node('div', 'setup-body');
  const seg = node('div', 'setup-seg');
  seg.setAttribute('role', 'group');
  seg.setAttribute('aria-label', 'Funding');
  for (const [id, label] of /** @type {const} */ ([['new', 'Create new'], ['existing', 'Use existing']])) {
    const btn = node('button', undefined, label);
    btn.type = 'button';
    btn.setAttribute('aria-pressed', String(s.funding === id));
    btn.onclick = () => { s.funding = id; render(); };
    seg.append(btn);
  }
  body.append(seg);

  if (s.funding === 'new') {
    const amountBlock = node('div', 'setup-block');
    const lab = node('label', 'setup-field-label', 'Amount');
    lab.setAttribute('for', 'setup-amount');
    const box = node('div', 'amount');
    const input = /** @type {HTMLInputElement} */ (node('input'));
    input.id = 'setup-amount';
    input.inputMode = 'decimal';
    input.placeholder = '0.00';
    input.value = s.amount;
    input.oninput = () => { s.amount = input.value.replace(/[^0-9.,]/g, ''); input.value = s.amount; };
    const tokens = node('div', 'tokens');
    tokens.setAttribute('role', 'group');
    tokens.setAttribute('aria-label', 'Funding token');
    for (const [id, mark] of /** @type {const} */ ([['USDG', 'G'], ['ETH', 'Ξ']])) {
      const t = node('button');
      t.type = 'button';
      t.setAttribute('aria-pressed', String(s.token === id));
      const m = node('span', `token-mark token-mark--${id.toLowerCase()}`, mark);
      m.setAttribute('aria-hidden', 'true');
      t.append(m, document.createTextNode(id));
      t.onclick = () => { s.token = id; s.amount = ''; render(); };
      tokens.append(t);
    }
    box.append(input, tokens);
    amountBlock.append(lab, box, unwired('walletBalance'));
    body.append(amountBlock);
  } else {
    const block = node('div', 'setup-block');
    block.append(node('b', 'setup-field-label', 'Connect your wallet'),
      node('p', 'setup-p', 'Connecting an existing Robinhood Chain wallet creates a trading key for it. '
        + 'That key comes from the execution backend, which is not live yet.'));
    const connect = node('button', 'btn-primary', 'Connect wallet');
    connect.type = 'button';
    connect.disabled = true;
    connect.setAttribute('aria-describedby', 'setup-why');
    block.append(connect);
    body.append(block);
  }
  return body;
}

function render() {
  const panel = el('setup-panel');
  const r = s.row;
  panel.className = s.mode === 'counter' ? 'setup is-counter' : 'setup';
  panel.replaceChildren();

  const head = node('div', 'setup-head');
  const titles = node('div', 'setup-titles');
  const h = node('h2', undefined, `${s.mode === 'counter' ? 'Countertrade' : 'Copytrade'} ${shortAddr(r.address)}`);
  h.id = 'setup-title';
  titles.append(h, node('p', undefined,
    s.step === 1 ? 'Configure your trading preferences' : 'Configure your copytrading wallet details.'));
  const close = node('button', 'ghost');
  close.type = 'button';
  close.id = 'setup-close';
  close.setAttribute('aria-label', 'Close');
  close.append(icon(16, CLOSE, { 'stroke-width': 2.2 }));
  close.onclick = () => closeSetup();
  closeButton = close;
  head.append(titles, close);
  panel.append(head, s.step === 1 ? stepOne() : stepTwo());

  const foot = node('div', 'setup-foot');
  const progress = node('div', 'progress');
  const track = node('div', 'progress-track');
  const fill = node('div', 'progress-fill');
  fill.style.width = s.step === 1 ? '50%' : '100%';
  track.append(fill);
  progress.append(track, node('span', undefined, `${s.step}/2`));
  const back = node('button', 'btn-secondary', s.step === 1 ? 'Cancel' : 'Back');
  back.type = 'button';
  back.onclick = () => { if (s.step === 1) closeSetup(); else { s.step = 1; render(); } };
  const next = node('button', 'btn-primary', s.step === 1 ? 'Continue' : 'Start');
  next.type = 'button';
  next.id = 'setup-next';
  if (s.step === 1) {
    next.onclick = () => { s.step = 2; render(); };
  } else {
    // Nothing is behind this button. Disabled, and the reason is on the page beside it.
    next.disabled = true;
    next.setAttribute('aria-describedby', 'setup-why');
  }
  foot.append(progress, node('div', 'setup-foot-spacer'), back, next);
  panel.append(foot);
  if (s.step === 2) {
    const why = node('p', 'setup-why', 'Copying is not live yet. Nothing is funded, copied or signed from this dialog.');
    why.id = 'setup-why';
    panel.append(why);
  }
}

/** @param {KeyboardEvent} e */
function onKey(e) {
  const backdrop = el('setup');
  if (backdrop.hidden) return;
  if (e.key === 'Escape') { closeSetup(); return; }
  if (e.key !== 'Tab') return;
  const items = [...el('setup-panel').querySelectorAll('button:not([disabled]), input, [tabindex]')];
  if (!items.length) return;
  const first = /** @type {HTMLElement} */ (items[0]);
  const last = /** @type {HTMLElement} */ (items[items.length - 1]);
  const active = document.activeElement;
  if (e.shiftKey && active === first) { e.preventDefault?.(); last.focus(); }
  else if (!e.shiftKey && active === last) { e.preventDefault?.(); first.focus(); }
}
let bound = false;
/** @type {HTMLElement | null} */
let closeButton = null;

/**
 * @param {any} row a leaderboard row from the build
 * @param {{ windowLabel: string, from?: HTMLElement }} opts
 */
export function openSetup(row, opts) {
  Object.assign(s, { row, windowLabel: opts.windowLabel, from: opts.from ?? null, step: 1, mode: 'copy',
    tab: 'Configuration', funding: 'new', token: 'USDG', amount: '', extra: [], addError: '',
    values: { ...DEFAULTS }, assets: {} });
  const backdrop = el('setup');
  backdrop.hidden = false;
  render();
  // The dialog has no page of its own, so it carries a query instead: a reload or a shared
  // link lands back on it rather than on the grid behind it.
  try {
    const url = `${globalThis.location?.pathname ?? ''}?setup=${row.address}`;
    globalThis.history?.replaceState?.(null, '', url);
  } catch { /* no history in this environment */ }
  if (!bound) {
    document.addEventListener('keydown', onKey);
    backdrop.addEventListener('click', (e) => { if (e.target === backdrop) closeSetup(); });
    bound = true;
  }
  closeButton?.focus();
}

export function closeSetup() {
  el('setup').hidden = true;
  try {
    globalThis.history?.replaceState?.(null, '', globalThis.location?.pathname ?? '');
  } catch { /* no history in this environment */ }
  s.from?.focus();
}
