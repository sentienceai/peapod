/**
 * Trader profile (preview): the handoff's profile, holding what an address actually has.
 *
 * The mockup's profile is mostly account state — portfolio value, a holdings table with
 * balances and average cost, cash, unrealized PnL, Sharpe, max drawdown — and all of it
 * needs the transfer index. Those slots say so.
 *
 * Two figures take the place of the mockup's Max drawdown and ROI WITHOUT taking their
 * names, because they are not the same measurements (see figures.js):
 *   Realized drawdown        the deepest fall of the closed-round-trip curve, in dollars.
 *   Return on matched cost   realized over the cost of the buys that were matched.
 * Each is labelled for what it measures and sits next to the account-level slot it is not,
 * so the difference is on the page rather than in someone's head.
 *
 * Cohort labels ("Whale", "Extremely profitable") are absent: the live site ships criteria
 * beside every label, and those two have none that is not just the ranking again.
 */

import { areaChart } from '../web/lib/chart.js';
import { chanceBand, coverage } from '../web/lib/evidence.js';
import { copyButton } from '../web/lib/copy.js';
import { setTokenLogos, tokenCell } from '../web/lib/token.js';
import { FIGURE_NOTES, realizedDrawdown, returnOnMatchedCost } from './figures.js';
import { unwired } from './needs.js';
import { money, mountTheme, node, shortAddr, signedMoney } from './chrome.js';
import { openSetup } from './setup.js';

/** @param {string} id */
const el = (id) => /** @type {HTMLElement} */ (document.getElementById(id));

/** @param {string} pathname */
export function addressFrom(pathname) {
  const raw = String(pathname).replace(/^\/trader\//, '').toLowerCase();
  return /^0x[0-9a-f]{40}$/.test(raw) ? raw : null;
}

/** @param {number} s */
function hold(s) {
  if (!Number.isFinite(s) || s <= 0) return null;
  if (s < 90) return `${Math.round(s)}s`;
  if (s < 5400) return `${Math.round(s / 60)}m`;
  if (s < 172800) return `${(s / 3600).toFixed(1)}h`;
  return `${(s / 86400).toFixed(1)}d`;
}

/**
 * A stat tile. `value` is already a node or a string; nothing here invents a placeholder —
 * a figure with no value is an unwired slot instead.
 * @param {string} label @param {HTMLElement | string} value @param {string} [sub] @param {string} [title]
 */
function tile(label, value, sub, title) {
  const t = node('div', 'tile');
  t.append(node('span', 'stat-label', label));
  if (typeof value === 'string') t.append(node('span', 'stat-value', value));
  else { value.className = `${value.className} stat-value`; t.append(value); }
  if (sub) t.append(node('span', 'stat-sub', sub));
  if (title) t.setAttribute('title', title);
  return t;
}

/** @param {any} d the address payload @param {string} addr */
function renderQualified(d, addr) {
  const s = d.summary;
  const band = chanceBand(Math.round((s.win_rate / 100) * s.round_trips), s.round_trips);
  const dd = realizedDrawdown(d.series ?? [], s);
  const roc = returnOnMatchedCost(s);
  const cov = coverage(s.out_of_scope_volume, s.total_volume);

  el('status').replaceChildren(node('p', 'profile-note',
    `Realized PnL over ${d.window?.label ?? 'this window'}, round-trips only: bought and sold `
    + 'on-chain, matched first-in-first-out. Holdings acquired any other way are out of '
    + 'scope, not estimated.'));

  const tiles = el('tiles');
  tiles.replaceChildren();
  tiles.append(tile('Realized', signedMoney(s.realized), 'Round-trips only'));
  tiles.append(tile('Round-trips', String(s.round_trips), `${cov.toFixed(0)}% of selling covered`,
    'Share of this address’s selling that had an on-chain buy behind it'));
  tiles.append(tile('Win rate', `${s.win_rate.toFixed(1)}%`, band.label,
    'The rate against a coin-flip null; the verdict is the exact binomial test.'));

  // The two figures that are not the mockup's two. Labelled as what they are, and each
  // says what it excludes rather than leaving the reader to assume.
  // "At least" when the figure had to come from the sampled curve: a thinned series can
  // step over the trough, so the number is a floor and is not shown as anything else.
  tiles.append(tile('Realized drawdown',
    dd.depth > 0 ? `−${money(dd.depth)}` : 'None',
    dd.depth > 0
      ? (dd.exact
        ? `From a ${money(dd.peak)} peak, over ${dd.closes} closes`
        : `At least. From a ${money(dd.peak)} peak, on a ${dd.points}-point sample of ${dd.closes} closes`)
      : `Never below its peak over ${dd.closes} closes`,
    dd.exact ? FIGURE_NOTES.realizedDrawdown
      : `${FIGURE_NOTES.realizedDrawdown} ${FIGURE_NOTES.realizedDrawdownSampled}`));
  if (roc) {
    tiles.append(tile('Return on matched cost', `${roc.pct >= 0 ? '+' : '−'}${Math.abs(roc.pct).toFixed(1)}%`,
      `On ${money(roc.cost)} of matched buys`, FIGURE_NOTES.returnOnMatchedCost));
  }
  tiles.append(tile('Median hold', hold(s.median_hold_s) ?? 'Not measured', `Longest win streak ${s.longest_win_streak}`));
  tiles.append(tile('Style', s.style, s.style_basis));
  tiles.append(tile('Matched volume', money(s.matched_volume), `${s.matched_share_pct.toFixed(1)}% of ${money(s.total_volume)} traded`));
  tiles.append(tile('Percentile', `${s.percentile.toFixed(1)}`,
    `of ${d.field.qualifying.toLocaleString('en-US')} qualifying; ${d.field.at_a_loss_pct.toFixed(1)}% lost money`));

  // The account-level slots, beside the figures they are not.
  el('tiles-unwired').replaceChildren(unwired('accountValue'), unwired('roi'),
    unwired('drawdown'), unwired('sharpe'));

  // The curve: cumulative realized, split at zero by the shared chart.
  const curve = el('curve');
  curve.replaceChildren();
  const { svg } = areaChart((d.series ?? []).map((/** @type {number[]} */ p) => [p[0], p[1]]),
    { width: 800, height: 220 });
  curve.append(svg);
  el('curve-sub').textContent = `Running total of ${s.round_trips} closed round-trips. `
    + 'It moves only when something closes, so an open position is not in it.';

  // Win/loss squares: filled is a win, hollow is a loss, so it reads without colour.
  const seq = el('sequence');
  seq.replaceChildren();
  const strip = node('div', 'streak');
  const shown = d.sequence ?? [];
  for (const win of shown) strip.append(node('i', win ? '' : 'loss'));
  strip.setAttribute('aria-label', `${shown.length} most recent closes, in order`);
  seq.append(strip, node('span', 'stat-sub',
    `Filled is a win, hollow is a loss — the ${shown.length} most recent of ${s.round_trips} closes.`));

  // What it trades: the quote mix and the tokens, both from the build.
  const mix = el('mix');
  mix.replaceChildren();
  for (const q of s.quote_mix ?? []) {
    const row = node('div', 'mix-row');
    row.append(node('span', 'mix-name', q.quote), node('span', 'mix-pct', `${q.pct.toFixed(1)}%`));
    const bar = node('div', 'bar');
    const fill = node('i');
    fill.style.width = `${q.pct}%`;
    bar.append(fill);
    row.append(bar, node('span', 'stat-sub', money(q.volume)));
    mix.append(row);
  }
  const top = [...(d.tokens ?? [])].sort((/** @type {any} */ a, /** @type {any} */ b) => b.matched - a.matched).slice(0, 6);
  const toks = node('div', 'mix-tokens');
  for (const t of top) {
    const chip = node('div', 'mix-token');
    // Into the asset page, where the holder side of this token will live.
    const linkable = /^[A-Za-z0-9.]{1,16}$/.test(t.token);
    const link = /** @type {HTMLElement} */ (linkable ? node('a', 'mix-link') : node('span', 'mix-link'));
    if (linkable) {
      link.setAttribute('href', `/asset/${t.token}`);
      link.setAttribute('aria-label', `${t.token} asset page`);
    }
    link.append(tokenCell(t.token));
    chip.append(link, node('span', 'stat-sub', `${t.round_trips} closed`), signedMoney(t.realized));
    toks.append(chip);
  }
  if (top.length) {
    mix.append(node('span', 'stat-label', `Tokens (${s.tokens_traded} traded)`), toks);
  }

  // Labels, each with the rule that earns it.
  const labels = el('labels');
  labels.replaceChildren();
  for (const l of d.labels ?? []) {
    const item = node('div', 'label-item');
    item.dataset.earned = String(Boolean(l.earned));
    item.append(node('b', undefined, l.label), node('small', undefined, l.criteria));
    labels.append(item);
  }

  // Holdings: the mockup's table, unwired, with the reason it cannot be filled.
  el('holdings-sub').textContent = 'Balances, average cost and unrealized PnL are account '
    + 'state, not trade history.';
  el('holdings').replaceChildren(unwired('holdings'));

  // Activity: only tabs the data fills.
  const TABS = [
    { id: 'round_trips', label: 'Round-trips', rows: d.round_trips ?? [], total: s.round_trips },
    { id: 'trades', label: 'Trades', rows: d.trades ?? [], total: s.position_changes },
    { id: 'tokens', label: 'Tokens', rows: d.tokens ?? [], total: s.tokens_traded },
  ];
  const tabs = el('tabs');
  const table = el('table');
  let active = TABS[0].id;
  const drawTable = () => {
    const tab = /** @type {any} */ (TABS.find((t) => t.id === active));
    table.replaceChildren();
    const capped = tab.rows.length < tab.total;
    if (capped) {
      table.append(node('p', 'stat-sub',
        `Showing the most recent ${tab.rows.length} of ${tab.total.toLocaleString('en-US')}.`));
    }
    const grid = node('div', `rowtable rowtable--${tab.id}`);
    /** @param {string[]} cells @param {boolean} head */
    const line = (cells, head) => {
      const r = node('div', head ? 'rt-head' : 'rt-row');
      for (const c of cells) r.append(node('span', undefined, c));
      return r;
    };
    if (tab.id === 'round_trips') {
      grid.append(line(['Token', 'Qty', 'Buy', 'Sell', 'Held', 'Realized'], true));
      for (const t of tab.rows.slice(0, 50)) {
        const r = node('div', 'rt-row');
        r.append(tokenCell(t.token), node('span', undefined, t.qty.toPrecision(4)),
          node('span', undefined, `$${t.buy.toPrecision(4)}`), node('span', undefined, `$${t.sell.toPrecision(4)}`),
          node('span', undefined, hold(t.held) ?? '0s'), signedMoney(t.realized));
        grid.append(r);
      }
    } else if (tab.id === 'trades') {
      grid.append(line(['Token', 'Side', 'Qty', 'Value', 'Price'], true));
      for (const t of tab.rows.slice(0, 50)) {
        const r = node('div', 'rt-row');
        r.append(tokenCell(t.token), node('span', undefined, t.side), node('span', undefined, t.qty.toPrecision(4)),
          node('span', undefined, money(t.value)), node('span', undefined, `$${t.price.toPrecision(4)}`));
        grid.append(r);
      }
    } else {
      grid.append(line(['Token', 'Closed', 'Win rate', 'Matched', 'Realized'], true));
      for (const t of tab.rows.slice(0, 50)) {
        const r = node('div', 'rt-row');
        r.append(tokenCell(t.token), node('span', undefined, String(t.round_trips)),
          node('span', undefined, `${t.win_rate.toFixed(0)}%`), node('span', undefined, money(t.matched)),
          signedMoney(t.realized));
        grid.append(r);
      }
    }
    table.append(grid);
  };
  const renderTabs = () => {
    tabs.replaceChildren();
    for (const t of TABS) {
      const b = node('button');
      b.type = 'button';
      b.setAttribute('role', 'tab');
      // The count sits beside the label, as the live detail view does: on a page whose
      // claim rests on how many closes an address has, that number belongs where it is read.
      b.append(document.createTextNode(t.label), node('span', 'tab-n', String(t.total)));
      b.setAttribute('aria-selected', String(active === t.id));
      b.onclick = () => { active = t.id; renderTabs(); drawTable(); };
      tabs.append(b);
    }
  };
  renderTabs();
  el('tabs-sub').textContent = 'Positions, balances and transfers are not here: they need the transfer index.';
  drawTable();

  // The action. It opens the same setup dialog the grid does, which starts nothing.
  const act = el('actions');
  act.replaceChildren();
  const go = node('button', 'btn-copy btn-copy--lg', 'Copy this trader');
  go.id = 'copy-this-trader';
  go.type = 'button';
  go.setAttribute('aria-label', `Set up copying ${addr}`);
  const row = { address: addr, realized: s.realized, wins: Math.round((s.win_rate / 100) * s.round_trips),
    round_trips: s.round_trips, tokens: (d.tokens ?? []).map((/** @type {any} */ t) => t.token) };
  go.onclick = () => openSetup(row, { windowLabel: d.window?.label ?? '', from: go });
  act.append(go, unwired('copyScore', { compact: true }));
}

/** @param {any} d @param {string} addr */
function renderUnqualified(d, addr) {
  // Traded, but never closed a round-trip. It says what the address DID do, and shows no
  // zero where there is no figure.
  const s = d.summary ?? {};
  el('status').replaceChildren(
    node('p', 'profile-note', d.explain?.headline ?? 'No completed round-trips in this window.'),
    node('p', 'profile-note', d.explain?.detail ?? ''),
    node('p', 'profile-note', d.explain?.not_estimated ?? ''));
  const tiles = el('tiles');
  tiles.replaceChildren();
  tiles.append(tile('Realized', 'No realized PnL', 'Nothing closed in this window'));
  if (Number.isFinite(s.position_changes)) tiles.append(tile('Position changes', String(s.position_changes)));
  if (Number.isFinite(s.total_volume)) tiles.append(tile('Volume traded', money(s.total_volume)));
  if (Number.isFinite(s.out_of_scope_volume)) {
    tiles.append(tile('Sold with no on-chain buy', money(s.out_of_scope_volume), 'Out of scope, not estimated'));
  }
  el('tiles-unwired').replaceChildren(unwired('accountValue'), unwired('holdings'));
  el('curve-sub').textContent = 'Nothing has closed, so there is no realized curve to draw.';
  el('holdings-sub').textContent = 'Balances are account state, not trade history.';
  el('holdings').replaceChildren(unwired('holdings'));
  el('tabs-sub').textContent = 'Trades this address made in the window.';
  el('actions').replaceChildren(node('p', 'stat-sub',
    'Nothing to copy: this address has no closed round-trip to judge.'));
  void addr;
}

async function main() {
  mountTheme();
  const addr = addressFrom(globalThis.location?.pathname ?? '');
  el('crumb').textContent = addr ? shortAddr(addr) : 'Unknown';
  if (!addr) {
    el('who').textContent = 'Not an address';
    el('status').replaceChildren(node('p', 'profile-note',
      'That is not a 40-character address, so there is nothing to look up.'));
    return;
  }
  el('avatar').textContent = addr.slice(2, 4).toUpperCase();
  const who = el('who');
  who.replaceChildren(document.createTextNode(shortAddr(addr)), copyButton(addr));
  who.setAttribute('title', addr);

  setTokenLogos(await fetch('/api/leaderboard/tokens/tokens').then((r) => (r.ok ? r.json() : {})).catch(() => ({})));
  const res = await fetch(`/api/address/${addr}`);
  if (!res.ok) {
    el('status').replaceChildren(node('p', 'profile-note',
      'No activity in this window. That means this address did not trade in these pools '
      + 'over the window — not that it has never traded.'));
    el('footnote').replaceChildren(node('span', undefined, 'Preview'));
    return;
  }
  const d = await res.json();
  el('tags').replaceChildren();
  for (const u of d.universes ?? []) el('tags').append(node('span', 'tag', u === 'rwa' ? 'Stocks' : 'Memecoins'));
  if (d.status === 'no_round_trips') renderUnqualified(d, addr);
  else renderQualified(d, addr);

  // /trader/<address>?setup=<address> opens the wizard here too, so a link into the flow
  // lands on the same dialog wherever it was sent from.
  if (/[?&]setup=/.test(globalThis.location?.search ?? '')) {
    /** @type {any} */ (document.getElementById('copy-this-trader'))?.onclick?.({});
  }

  const f = el('footnote');
  f.replaceChildren(node('span', undefined, 'Preview'), node('span', 'pfoot-sep'),
    node('span', undefined, 'Copying is not live. Nothing here places, copies or simulates a trade.'),
    node('span', 'pfoot-sep'),
    node('span', undefined, 'Elapsed times and windows are measured from the end of the tape.'));
}

await main();
