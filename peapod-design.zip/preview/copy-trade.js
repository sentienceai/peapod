/**
 * Copy trade (preview): the handoff's grid, filled only with what the build holds.
 *
 * REAL: who traded, what they realized over the window on round-trips, the series behind
 * it, the tokens, when they last traded, and the chance test on their win count — the same
 * store, the same scopes and the same criterion as the live traders page.
 *
 * UNWIRED: account value, ROI and the copy score. Each renders what it needs, from
 * needs.js. The mockup's $/% toggle, its "Largest portfolio" and "Highest copy score"
 * sorts, and its 30D/YTD windows are absent rather than disabled: a control that cannot
 * do anything advertises a figure that does not exist. They arrive with their data.
 */

import { chanceBand, coverage, CRITERION } from '../web/lib/evidence.js';
import { sparkline } from '../web/lib/spark.js';
import { copyButton } from '../web/lib/copy.js';
import { setTokenLogos } from '../web/lib/token.js';
import { subsidyNote } from '../web/lib/findings.js';
import { unwired } from './needs.js';
import { icon, mountTheme, node, shortAddr, signedMoney } from './chrome.js';
import { openSetup } from './setup.js';

/** @param {string} id */
const el = (id) => /** @type {HTMLElement} */ (document.getElementById(id));

const CATEGORIES = [{ id: 'all', label: 'All' }, { id: 'rwa', label: 'Stocks' }, { id: 'pons', label: 'Memecoins' }];
const SORTS = [
  { id: 'realized', label: 'Highest realized' },
  { id: 'closes', label: 'Most closes' },
  { id: 'recent', label: 'Most recent' },
];
const PAGE = 24;

const state = {
  /** @type {any} */ manifest: null,
  /** @type {any} */ index: null,
  /** @type {any} */ data: null,
  cat: 'all',
  window: '',
  sort: 'realized',
  query: '',
  limit: PAGE,
  methodOpen: false,
};

/**
 * Elapsed time from the END OF THE TAPE, not from now: the data is a fixed window.
 * @param {number} ts @param {number} anchor
 */
function ago(ts, anchor) {
  const s = Math.max(0, anchor - ts);
  if (s < 3600) return `${Math.max(1, Math.round(s / 60))}M AGO`;
  if (s < 86400) return `${Math.round(s / 3600)}H AGO`;
  return `${Math.round(s / 86400)}D AGO`;
}

/** @param {any} r */
function sortKey(r) {
  if (state.sort === 'closes') return r.round_trips;
  if (state.sort === 'recent') return r.last_ts ?? 0;
  return r.realized;
}

const windowLabel = () => state.index?.windows?.find(
  (/** @type {any} */ w) => w.window === state.window)?.label ?? state.window;

/**
 * A token, linked to its asset page. The symbol is shape-checked the same way the gate
 * checks it, so a token whose symbol could not be a path is drawn without a link rather
 * than as one that leads to a 404.
 * @param {string} token
 */
function assetLink(token) {
  if (!/^[A-Za-z0-9.]{1,16}$/.test(token)) return node('span', 'dot', token.slice(0, 1));
  const a = node('a', 'dot', token.slice(0, 1));
  a.setAttribute('href', `/asset/${token}`);
  a.setAttribute('aria-label', `${token} asset page`);
  a.setAttribute('title', token);
  return a;
}

/** @param {any} r */
function evidence(r) {
  const b = chanceBand(r.wins, r.round_trips);
  const wrap = node('div', `ev v-${b.verdict}`);
  const head = node('div', 'ev-head');
  head.append(node('b', undefined, `${(b.rate * 100).toFixed(0)}% win`));
  head.append(node('span', 'ev-verdict tcard-verdict', b.label));
  const track = node('div', 'ev-track');
  const band = node('i', 'ev-band');
  band.style.left = `${b.lo * 100}%`;
  band.style.width = `${(b.hi - b.lo) * 100}%`;
  const nul = node('i', 'ev-null');
  const mark = node('i', 'ev-mark');
  mark.style.left = `${b.rate * 100}%`;
  track.append(band, nul, mark);
  const foot = node('div', 'ev-foot',
    `chance ${Math.round(b.lo * 100)}–${Math.round(b.hi * 100)}% over ${r.round_trips}`);
  wrap.append(head, track, foot);
  return wrap;
}

/** @param {any} r */
function card(r) {
  const c = node('article', 'ccard');
  c.setAttribute('aria-label', `Trader ${r.address}`);

  const head = node('div', 'ccard-head');
  const avatar = node('span', 'avatar', r.address.slice(2, 4).toUpperCase());
  avatar.setAttribute('aria-hidden', 'true');
  const who = node('div', 'ccard-who');
  const name = node('div', 'ccard-name');
  // The card's way into the profile. A link, not a click handler on the article, so it is
  // reachable by keyboard and its target is visible before anyone follows it.
  const open = node('a', 'ccard-link', shortAddr(r.address));
  open.setAttribute('href', `/trader/${r.address}`);
  open.setAttribute('aria-label', `Open the profile for ${r.address}`);
  name.append(open, copyButton(r.address));
  const dots = node('div', 'dots');
  const tokens = r.tokens ?? [];
  dots.setAttribute('aria-label', `Traded ${tokens.join(', ')}`);
  for (const t of tokens.slice(0, 4)) dots.append(assetLink(t));
  if ((r.token_count ?? tokens.length) > 4) {
    dots.append(node('span', 'dot dot--more', `+${(r.token_count ?? tokens.length) - 4}`));
  }
  who.append(name, dots);
  const when = node('span', 'ago');
  when.append(icon(11, [['circle', { cx: 12, cy: 12, r: 9 }], ['path', { d: 'M12 7v5l3 2' }]], { 'stroke-width': 2.5 }));
  when.append(document.createTextNode(ago(r.last_ts, state.data.to_ts)));
  when.setAttribute('title', 'Last trade, measured from the end of the tape');
  head.append(avatar, who, when);

  const mid = node('div', 'ccard-mid');
  const figs = node('div', 'ccard-figs');
  const fig = node('div', 'fig');
  fig.append(signedMoney(r.realized), node('span', 'fig-label', `Realized · ${windowLabel()} · round-trips only`));
  figs.append(fig);
  const rec = node('span', 'fig-label tcard-record',
    `${r.round_trips} closed · ${coverage(r.out_of_scope_volume, r.total_volume).toFixed(0)}% covered`);
  rec.setAttribute('title', 'Share of this address\'s selling that had an on-chain buy behind it');
  figs.append(rec);
  const spark = node('div', 'ccard-spark');
  spark.append(sparkline(r.spark ?? [], { width: 200, height: 88 }));
  mid.append(figs, spark);

  const gaps = node('div', 'ccard-unwired');
  gaps.append(unwired('accountValue', { compact: true }), unwired('copyScore', { compact: true }));

  const foot = node('div', 'ccard-foot');
  const go = node('button', 'btn-copy', 'Copy');
  go.type = 'button';
  go.setAttribute('aria-label', `Set up copying ${r.address}`);
  go.onclick = () => openSetup(r, { windowLabel: windowLabel(), from: go });
  foot.append(evidence(r), go);

  c.append(head, mid, gaps, foot);
  return c;
}

function renderControls() {
  const cats = el('categories');
  cats.replaceChildren();
  for (const cat of CATEGORIES) {
    const b = node('button', undefined, cat.label);
    b.type = 'button';
    const has = state.index?.views?.some(
      (/** @type {any} */ v) => v.scope === cat.id && v.window === state.window);
    // A scope with no build behind it is disabled, never a fallback to another's numbers.
    b.disabled = !has;
    b.setAttribute('aria-pressed', String(state.cat === cat.id));
    b.onclick = () => { state.cat = cat.id; state.limit = PAGE; load(); };
    cats.append(b);
  }

  const sort = el('sort');
  sort.replaceChildren(document.createTextNode(SORTS.find((s) => s.id === state.sort)?.label ?? ''));
  sort.append(icon(14, [['path', { d: 'M7 4v16M3 8l4-4 4 4M17 20V4M13 16l4 4 4-4' }]]));
  sort.setAttribute('aria-label', `Sort: ${SORTS.find((s) => s.id === state.sort)?.label}. Change sort`);
  sort.onclick = () => {
    const i = SORTS.findIndex((s) => s.id === state.sort);
    state.sort = SORTS[(i + 1) % SORTS.length].id;
    renderControls();
    renderGrid();
  };

  const wins = el('windows');
  wins.replaceChildren();
  for (const w of state.index?.windows ?? []) {
    const b = node('button', undefined, String(w.label).toUpperCase());
    b.type = 'button';
    b.setAttribute('aria-pressed', String(state.window === w.window));
    b.onclick = () => { state.window = w.window; state.limit = PAGE; load(); };
    wins.append(b);
  }

  const search = /** @type {HTMLInputElement} */ (/** @type {unknown} */ (el('search')));
  search.oninput = () => { state.query = search.value.trim().toLowerCase(); state.limit = PAGE; renderGrid(); };
}

/**
 * The caveat, above the grid. The same claims the live pages make, from the same build:
 * round-trips only, out of scope not estimated, which window, which pools, how many
 * qualified out of how many, and the gas subsidy.
 */
function renderCaveat() {
  const c = state.data.coverage;
  const box = el('caveat');
  box.replaceChildren();
  const line = node('span');
  line.append(node('b', undefined,
    `${c.addresses_qualifying.toLocaleString('en-US')} of ${c.addresses_seen.toLocaleString('en-US')} addresses`));
  line.append(document.createTextNode(
    ` closed a round-trip over ${c.window_label}. Realized PnL is round-trips only; everything else is out of scope, not estimated.`));
  const more = node('button', 'linkish', state.methodOpen ? 'Hide method' : 'How this is measured');
  more.type = 'button';
  more.setAttribute('aria-expanded', String(state.methodOpen));
  more.setAttribute('aria-controls', 'method');
  more.onclick = () => { state.methodOpen = !state.methodOpen; renderCaveat(); };
  const count = node('span', 'pcount',
    `Showing the top ${c.rows_shown.toLocaleString('en-US')} of ${c.addresses_qualifying.toLocaleString('en-US')}`);
  box.append(line, more, count);

  const method = el('method');
  method.hidden = !state.methodOpen;
  method.replaceChildren();
  /** @param {string} text */
  const para = (text) => method.append(node('p', undefined, text));
  para(`Ranked over ${c.universe}. ${c.note}`);
  para(c.usd_note);
  para(c.scope_note);
  para(CRITERION);
  if (c.magnitude_note) para(c.magnitude_note);
  para(c.truncation_note);
  const subsidy = state.data.provenance?.subsidy;
  if (subsidy?.ends) para(subsidyNote(subsidy).text);
  else if (subsidy?.note) para(subsidy.note);
}

function renderGrid() {
  const grid = el('grid');
  grid.replaceChildren();
  const rows = [...(state.data?.rows ?? [])]
    .filter((/** @type {any} */ r) => !state.query || r.address.startsWith(state.query))
    .sort((/** @type {any} */ a, /** @type {any} */ b) => sortKey(b) - sortKey(a));
  if (!rows.length) {
    grid.append(node('p', 'pempty', state.query
      ? 'No ranked address starts with that. Addresses outside the ranking are on the leaderboard search.'
      : 'No build is being served yet.'));
  }
  for (const r of rows.slice(0, state.limit)) grid.append(card(r));
  const more = el('more');
  more.hidden = rows.length <= state.limit;
  more.onclick = () => { state.limit += PAGE; renderGrid(); };
}

function renderFooter() {
  const f = el('footnote');
  f.replaceChildren();
  f.append(node('span', undefined, 'Preview'));
  f.append(node('span', 'pfoot-sep'));
  f.append(node('span', undefined,
    'Copying is not live. Nothing here places, copies or simulates a trade.'));
  if (state.manifest?.build) {
    f.append(node('span', 'pfoot-sep'));
    const b = node('span', undefined, 'Build ');
    b.append(node('code', undefined, state.manifest.build));
    f.append(b);
  }
}

async function load() {
  renderControls();
  const view = state.index?.views?.find(
    (/** @type {any} */ v) => v.scope === state.cat && v.window === state.window);
  state.data = view
    ? await fetch(`/api/leaderboard/${view.scope}/${view.window}`).then((r) => r.json()).catch(() => null)
    : null;
  if (state.data) renderCaveat();
  renderGrid();
}

/**
 * The dialog's URL. There is no /copy-setup page — the wizard is a dialog — so it is
 * deep-linked instead: /copy-trade?setup=<address> opens it on load, and opening it writes
 * that query, which is what makes the step shareable and survivable across a reload.
 * @param {string} search
 */
export function setupTarget(search) {
  const m = /[?&]setup=(0x[0-9a-f]{40})\b/i.exec(String(search ?? ''));
  return m ? m[1].toLowerCase() : null;
}

/** @param {string} addr */
async function openFromQuery(addr) {
  const known = (state.data?.rows ?? []).find((/** @type {any} */ r) => r.address === addr);
  if (known) { openSetup(known, { windowLabel: windowLabel() }); return; }
  // Linked straight to an address outside the ranked rows: fetch its own record rather
  // than opening the dialog over numbers from a different address.
  const d = await fetch(`/api/address/${addr}`).then((r) => (r.ok ? r.json() : null)).catch(() => null);
  if (!d || d.status === 'no_round_trips') return;
  openSetup({ address: addr, realized: d.summary.realized,
    wins: Math.round((d.summary.win_rate / 100) * d.summary.round_trips),
    round_trips: d.summary.round_trips, tokens: (d.tokens ?? []).map((/** @type {any} */ t) => t.token) },
  { windowLabel: d.window?.label ?? windowLabel() });
}

mountTheme();
el('copying').replaceChildren(unwired('copying', { compact: true }));
state.manifest = await fetch('/api/manifest').then((r) => r.json()).catch(() => ({}));
state.index = await fetch('/api/leaderboard/index').then((r) => r.json()).catch(() => null);
state.window = state.index?.windows?.at(-1)?.window ?? '';
setTokenLogos(await fetch('/api/leaderboard/tokens/tokens').then((r) => (r.ok ? r.json() : {})).catch(() => ({})));
renderFooter();
await load();
const deepLink = setupTarget(globalThis.location?.search ?? '');
if (deepLink) await openFromQuery(deepLink);
